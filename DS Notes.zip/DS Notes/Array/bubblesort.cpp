// Bubble sort
// W.a.p to sort the elements of the array in ascending order using bubble sort
#include <iostream>
using namespace std;

int main()
{
int n,temp;
int a[20];
cout<<"Enter the size of the array: ";
cin>>n;
cout<<"Enter the elements: ";
for (int i = 0; i < n; i++)
{
cin>>a[i];
}
for(int i=0;i<(n-1);i++)
{
for (int j = 0; j < (n-i-1); j++)
{
if (a[j]>a[j+1])
{
temp=a[j];
a[j]=a[j+1];
a[j+1]=temp;
}
}
}

cout<<"Your sorted array is :";
for (int i = 0; i < n; i++)
{
cout<<a[i]<<" ";
}
return 0;
}