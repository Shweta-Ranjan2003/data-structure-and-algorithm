#include <iostream>
#include <string>
#include <set>
#include <vector>
using namespace std;

int main()
{ 
 int test;
 cin>>test;
 int result;
 set<vector<int>> s;
 set<string> str;
 while(test!=0){
    int arr[26];
    for(int i=0;i<26;i++){
        cin>>arr[i];
    }
    int strsize;
    cin>>strsize;
    while(strsize!=0){
        string temp;
        cin>>temp;
         str.insert(temp);
        vector<int>a;
        for(int i=0; i<temp.length();i++){
          a.push_back(arr[temp[i]-65]);
        }
        if(s.count(a)>0) {
            result++;
        }
        else s.insert(a);
        strsize--;
    }
   if(result>0) cout<<"Case #: YES"<<endl;
   else cout<<"Case #: NO"<<endl;
    test--;
 }
 return 0;
}